GITHUB ACTIONS APK BUILD KIT

1. Create a GitHub repository (for example, MyAndroidApp).
2. Upload MyAndroidApp_Project.zip to the repository root and commit it.
3. In the repository, create this file:
   .github/workflows/android-build.yml
   Paste the contents of android-build.yml from this kit and commit it.
4. Open the repository's Actions tab.
5. Select "Build Android APK", choose "Run workflow", and confirm.
6. When the run succeeds, open the run and download the
   "MyAndroidApp-debug-apk" artifact.
7. Extract the downloaded artifact ZIP on your phone; install app-debug.apk.

The provided source ZIP extracts into extracted/MyAndroidApp in the workflow.
This produces a debug APK for testing, not a Play Store release. Keep private
source code in a private GitHub repository.
