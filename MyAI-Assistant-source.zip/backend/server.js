import express from "express";

const app = express();
app.use(express.json({ limit: "1mb" }));

app.get("/health", (_req, res) => res.json({ ok: true, service: "MyAI Assistant" }));

app.post("/v1/chat/completions", async (req, res) => {
  const key = process.env.OPENAI_API_KEY;
  if (!key) return res.status(503).json({ error: "Backend API key is not configured." });

  const messages = Array.isArray(req.body?.messages) ? req.body.messages : [];
  if (!messages.length) return res.status(400).json({ error: "messages is required" });

  try {
    const upstream = await fetch(process.env.AI_API_URL || "https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${key}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        model: process.env.AI_MODEL || "gpt-4o-mini",
        messages: messages.slice(-24),
        temperature: 0.7
      })
    });
    const data = await upstream.json();
    if (!upstream.ok) return res.status(upstream.status).json({ error: data?.error?.message || "AI provider request failed" });
    return res.json({ reply: data?.choices?.[0]?.message?.content || "No response returned." });
  } catch {
    return res.status(502).json({ error: "Could not reach AI provider." });
  }
});

const port = Number(process.env.PORT || 3000);
app.listen(port, () => console.log(`MyAI backend listening on ${port}`));
