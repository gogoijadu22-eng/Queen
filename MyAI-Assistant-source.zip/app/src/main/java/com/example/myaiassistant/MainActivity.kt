package com.example.myaiassistant

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

// Deploy backend/ and replace this with its HTTPS /v1/chat/completions endpoint.
private const val AI_BASE_URL = "https://YOUR-BACKEND-HOST.example.com/v1/chat/completions"

data class ChatMessage(val role: String, val content: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MyAIApp() }
    }
}

@Composable
private fun MyAIApp() {
    val messages = remember {
        mutableStateListOf(ChatMessage("assistant", "Hello! I'm MyAI Assistant. What would you like help with?"))
    }
    var input by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()
    val listState = rememberLazyListState()

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Color(0xFF8AB4F8),
            background = Color(0xFF101318),
            surface = Color(0xFF191D24)
        )
    ) {
        Scaffold(
            containerColor = Color(0xFF101318),
            topBar = {
                Surface(color = Color(0xFF191D24), shadowElevation = 3.dp) {
                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(color = Color(0xFF8AB4F8), shape = RoundedCornerShape(12.dp)) {
                            Text("AI", Modifier.padding(horizontal = 10.dp, vertical = 8.dp), color = Color(0xFF101318), fontWeight = FontWeight.Bold)
                        }
                        Spacer(Modifier.width(12.dp))
                        Column {
                            Text("MyAI Assistant", fontSize = 19.sp, fontWeight = FontWeight.Bold, color = Color.White)
                            Text("Your AI companion", fontSize = 12.sp, color = Color(0xFFB9C0CC))
                        }
                    }
                }
            },
            bottomBar = {
                Surface(color = Color(0xFF191D24)) {
                    Column(Modifier.fillMaxWidth().imePadding().padding(12.dp)) {
                        error?.let { Text(it, color = Color(0xFFFF8A80), fontSize = 12.sp, modifier = Modifier.padding(bottom = 8.dp)) }
                        Row(
                            Modifier.fillMaxWidth().background(Color(0xFF252B35), RoundedCornerShape(24.dp)).padding(start = 16.dp, end = 8.dp, top = 8.dp, bottom = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            BasicTextField(
                                value = input,
                                onValueChange = { input = it },
                                modifier = Modifier.weight(1f).padding(vertical = 10.dp),
                                textStyle = androidx.compose.ui.text.TextStyle(color = Color.White, fontSize = 15.sp),
                                cursorBrush = androidx.compose.ui.graphics.SolidColor(Color(0xFF8AB4F8)),
                                decorationBox = { inner ->
                                    Box {
                                        if (input.isEmpty()) Text("Message MyAI...", color = Color(0xFF9AA3B2), fontSize = 15.sp)
                                        inner()
                                    }
                                }
                            )
                            Spacer(Modifier.width(8.dp))
                            IconButton(
                                onClick = {
                                    val prompt = input.trim()
                                    if (prompt.isNotEmpty() && !loading) {
                                        messages.add(ChatMessage("user", prompt))
                                        input = ""
                                        error = null
                                        loading = true
                                        scope.launch {
                                            val answer = withContext(Dispatchers.IO) { askAI(messages.toList()) }
                                            if (answer.startsWith("ERROR:")) error = answer.removePrefix("ERROR:")
                                            else messages.add(ChatMessage("assistant", answer))
                                            loading = false
                                        }
                                    }
                                },
                                enabled = input.isNotBlank() && !loading
                            ) {
                                Icon(Icons.Default.Send, contentDescription = "Send message", tint = Color(0xFF8AB4F8))
                            }
                        }
                        Text("AI can make mistakes. Check important information.", color = Color(0xFF858E9D), fontSize = 10.sp, modifier = Modifier.padding(start = 8.dp, top = 6.dp))
                    }
                }
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding)) {
                LazyColumn(
                    state = listState,
                    modifier = Modifier.weight(1f).fillMaxWidth(),
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 18.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(messages) { msg ->
                        val user = msg.role == "user"
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = if (user) Arrangement.End else Arrangement.Start) {
                            Surface(
                                color = if (user) Color(0xFF24466D) else Color(0xFF202630),
                                shape = RoundedCornerShape(18.dp),
                                modifier = Modifier.widthIn(max = 320.dp)
                            ) {
                                Text(msg.content, Modifier.padding(horizontal = 15.dp, vertical = 12.dp), color = Color.White, fontSize = 15.sp, lineHeight = 21.sp)
                            }
                        }
                    }
                    if (loading) item {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp, color = Color(0xFF8AB4F8))
                            Spacer(Modifier.width(10.dp))
                            Text("Thinking...", color = Color(0xFFB9C0CC), fontSize = 13.sp)
                        }
                    }
                }
                LaunchedEffect(messages.size, loading) {
                    if (messages.isNotEmpty()) listState.animateScrollToItem(
                        (messages.size - 1 + if (loading) 1 else 0).coerceAtMost(messages.size - 1 + if (loading) 1 else 0)
                    )
                }
            }
        }
    }
}

private fun askAI(history: List<ChatMessage>): String {
    if (AI_BASE_URL.contains("YOUR-BACKEND-HOST")) {
        return "ERROR: Set AI_BASE_URL in MainActivity.kt to your deployed HTTPS backend URL, then rebuild the APK."
    }
    var connection: HttpURLConnection? = null
    return try {
        connection = (URL(AI_BASE_URL).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 20000
            readTimeout = 60000
            doOutput = true
            setRequestProperty("Content-Type", "application/json")
        }
        val body = JSONObject().apply {
            put("messages", JSONArray().apply {
                history.takeLast(24).forEach { put(JSONObject().put("role", it.role).put("content", it.content)) }
            })
        }.toString()
        connection.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
        val code = connection.responseCode
        val stream = if (code in 200..299) connection.inputStream else connection.errorStream
        val text = stream.bufferedReader().use { it.readText() }
        if (code !in 200..299) "ERROR: AI service returned HTTP $code. Check backend configuration."
        else {
            val json = JSONObject(text)
            json.optString("reply").takeIf { it.isNotBlank() }
                ?: json.optJSONArray("choices")?.optJSONObject(0)?.optJSONObject("message")?.optString("content")
                ?: "I couldn't find a response in the server reply."
        }
    } catch (e: Exception) {
        "ERROR: Couldn't connect to the AI service. Check your internet and backend URL."
    } finally {
        connection?.disconnect()
    }
}
