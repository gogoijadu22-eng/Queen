# MyAI Assistant (Android starter)

A native Android chat app starter with an online-AI backend proxy.

## Important
- The Android app does **not** include an AI API key. Never put a private API key in an APK.
- Deploy the `backend/` service to a trusted HTTPS host, set `OPENAI_API_KEY` there, then set `AI_BASE_URL` in `app/src/main/java/com/example/myaiassistant/MainActivity.kt` to your backend URL.
- This starter uses an OpenAI-compatible Chat Completions endpoint. Provider/model availability and costs depend on your account.

## Build an APK using GitHub Actions
1. Create a GitHub repository named `MyAI-Assistant`.
2. Upload all files in this folder to the repository (keep the folder structure).
3. Open **Actions** and enable workflows if GitHub asks.
4. The workflow **Build Android APK** builds a debug APK.
5. Open the successful workflow run → **Artifacts** → download `MyAI-debug-apk`, unzip it, and find `app-debug.apk`.
6. On your Android phone, download the APK, open it, allow installation from that source if Android asks, then install.

## Backend setup
From the `backend/` folder, deploy it to a Node.js host that supports environment variables:
- `OPENAI_API_KEY` = your provider API key (keep secret)
- `AI_MODEL` = a model available to your account (default `gpt-4o-mini`)
- `PORT` = host-provided port (if required)

Set the Android app's `AI_BASE_URL` to `https://YOUR-HOST.example.com/v1/chat/completions`.
Use HTTPS only. The starter endpoint is intentionally not configured to a real provider until you deploy your own backend.

## Current scope
Includes a chat UI, loading/error states, and a GitHub Actions APK build. Voice, image understanding/generation, file uploads, and production account/security features are not included yet.
