MY ANDROID APP — BUILD-READY SOURCE PROJECT

This is the source project for the basic "My App" Android starter. It is not an APK.

BUILD AN APK
1. Install Android Studio on a computer: https://developer.android.com/studio
2. Extract this ZIP.
3. In Android Studio, choose Open and select the MyAndroidApp folder.
4. Allow Gradle sync to finish and install any requested Android SDK components.
5. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
6. Use the APK link shown by Android Studio (normally app/build/outputs/apk/debug/app-debug.apk).
7. Transfer the APK to your Android phone and open it. If prompted, allow installation from that source.

NOTES
- Internet access is needed on the first build so Gradle can download the Android Gradle Plugin and Kotlin plugin.
- This ZIP does not include a Gradle wrapper or a compiled APK.
- The app's launcher label and screen can be customized in the app source and manifest.
